-- Quantité de fleur de sel achetée par client
SELECT CLIENT.nomCli, CLIENT.precisionCli, CLIENT.villeCli, SUM(CONCERNER.qteSort) As qteAchatFleurDeSelenT
FROM CLIENT 
JOIN SORTIE ON CLIENT.numCli = SORTIE.numCli
JOIN CONCERNER ON CONCERNER.numSort = SORTIE.numSort
JOIN PRODUIT ON CONCERNER.numPdt = PRODUIT.numPdt
WHERE PRODUIT.libPdt = "Fleur de sel"
GROUP BY CLIENT.nomCli, CLIENT.precisionCli, CLIENT.villeCli;

-- Quantité d'argent dépensée par client de plus de 100000€
SELECT CLIENT.nomCli, CLIENT.precisionCli, CLIENT.villeCli, SUM(qteSort*prixVente) As valeurTotAchaten€
FROM CLIENT
JOIN SORTIE ON CLIENT.numCli = SORTIE.numCli
JOIN CONCERNER ON CONCERNER.numSort = SORTIE.numSort
JOIN PRODUIT ON CONCERNER.numPdt = PRODUIT.numPdt
JOIN COUTER ON COUTER.numPdt = PRODUIT.numPdt
GROUP BY CLIENT.nomCli, CLIENT.precisionCli, CLIENT.villeCli
HAVING SUM(qteSort*prixVente) >= 100000;

-- Les clients qui n'ont rien acheté
SELECT CLIENT.nomCli, CLIENT.precisionCli, CLIENT.villeCli
FROM CLIENT
WHERE CLIENT.numCli NOT IN (SELECT CLIENT.numCli
    FROM CLIENT
    JOIN SORTIE ON CLIENT.numCli = SORTIE.numCli);

-- Ajouter un client, ici François GARNIER
INSERT INTO CLIENT
VALUES(5, "GARNIER", "François", "NIORT");

-- Création d'un utilisateur Commercial qui a accès aux tables Sauniers et Clients pour trouver d'autres clients et sauniers
CREATE USER 'Commercial' IDENTIFIED BY 'Commercial';
GRANT SELECT ON SAUNIERS TO Commercial;
GRANT SELECT ON CLIENTS TO Commercial;

-- Produits les plus vendus en termes de quantité totale
SELECT PRODUIT.libPdt, SUM(CONCERNER.qteSort) AS totalVendu
FROM PRODUIT
JOIN CONCERNER ON PRODUIT.numPdt = CONCERNER.numPdt
GROUP BY PRODUIT.libPdt
ORDER BY totalVendu DESC;

-- Revenus totaux générés par produit
SELECT PRODUIT.libPdt, SUM(CONCERNER.qteSort * COUTER.prixVente) AS revenuTotal
FROM PRODUIT
JOIN CONCERNER ON PRODUIT.numPdt = CONCERNER.numPdt
JOIN COUTER ON PRODUIT.numPdt = COUTER.numPdt
GROUP BY PRODUIT.libPdt
ORDER BY revenuTotal DESC;

-- Création d'une vue pour savoir ce que chaque saunier produit
CREATE VIEW Sauniers (numSau, nom, prenom, ville, produit, qteProduite) AS
SELECT SAUNIER.numSau, nomSau, prenomSau, villeSau, libPdt, SUM(qteEnt)
FROM SAUNIER
JOIN ENTREE ON SAUNIER.numSau = ENTREE.numSau
JOIN PRODUIT ON ENTREE.numPdt = PRODUIT.numPdt
GROUP BY SAUNIER.numSau, nomSau, prenomSau, villeSau, libPdt;

-- Les sauniers qui ont produit le plus de fleur de sel
SELECT *
FROM Sauniers
WHERE produit = "Fleur de sel"
ORDER BY qteProduite DESC;

-- Les sauniers qui ont produit le plus de gros sel
SELECT *
FROM Sauniers
WHERE produit = "Gros sel"
ORDER BY qteProduite DESC;
