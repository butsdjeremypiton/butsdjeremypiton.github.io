-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le :  jeu. 17 avr. 2025 à 16:31
-- Version du serveur :  5.7.17
-- Version de PHP :  5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `selmarin`
--

-- --------------------------------------------------------

--
-- Structure de la table `client`
--

CREATE TABLE `client` (
  `numCli` varchar(50) NOT NULL,
  `nomCli` varchar(50) NOT NULL,
  `precisionCli` varchar(50) NOT NULL,
  `villeCli` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `client`
--

INSERT INTO `client` (`numCli`, `nomCli`, `precisionCli`, `villeCli`) VALUES
('1', 'CAVANA', 'Marie', 'LA ROCHELLE'),
('10', 'LIDL', 'Centrale d\'Achats', 'PUILBOREAU'),
('11', 'CARREFOUR', 'Centrale d\'Achats', 'LA ROCHELLE'),
('2', 'BURLET', 'Michel', 'LAGORD'),
('3', 'PEUTOT', 'Maurice', 'LAGORD'),
('4', 'ORGEVAL', 'Centrale d’Achats', 'SURGERES'),
('5', 'SICAAP', 'Centrale d\'Achats', 'FONTCOUVERTE'),
('6', 'GIE DE L\'AUNIS', 'Centrale d\'Achats', 'VOUHE'),
('7', 'EVEILLE', 'Johann', 'LA ROCHELLE'),
('8', 'BARBOTTIN', 'Olivier', 'MEURSAC'),
('9', 'UNION DES PRODUCTEURS DE LA MER', 'Centrale d\'Achats', 'RIVEDOUX');

-- --------------------------------------------------------

--
-- Structure de la table `concerner`
--

CREATE TABLE `concerner` (
  `numSort` int(11) NOT NULL,
  `numPdt` int(11) NOT NULL,
  `qteSort` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `concerner`
--

INSERT INTO `concerner` (`numSort`, `numPdt`, `qteSort`) VALUES
(20231, 1, 500),
(20234, 1, 250),
(20235, 1, 150),
(20237, 1, 500),
(20241, 1, 300),
(20242, 1, 200),
(20243, 1, 100),
(202310, 1, 700),
(202311, 1, 200),
(202313, 1, 500),
(202315, 1, 100),
(202316, 1, 350),
(202318, 1, 100),
(202319, 1, 300),
(202320, 1, 400),
(202322, 1, 200),
(202323, 1, 400),
(202324, 1, 150),
(202325, 1, 300),
(202327, 1, 600),
(202328, 1, 400),
(202329, 1, 300),
(202330, 1, 100),
(202331, 1, 500),
(202332, 1, 200),
(202333, 1, 200),
(202335, 1, 200),
(202337, 1, 300),
(202339, 1, 200),
(202340, 1, 300),
(202341, 1, 200),
(202342, 1, 650),
(202344, 1, 500),
(202345, 1, 300),
(202347, 1, 100),
(202348, 1, 700),
(202349, 1, 300),
(202351, 1, 300),
(202352, 1, 400),
(202354, 1, 300),
(202355, 1, 400),
(202357, 1, 200),
(202358, 1, 300),
(202359, 1, 400),
(202360, 1, 200),
(20231, 2, 500),
(20232, 2, 200),
(20233, 2, 300),
(20234, 2, 200),
(20236, 2, 100),
(20237, 2, 500),
(20238, 2, 200),
(20239, 2, 200),
(20241, 2, 400),
(20243, 2, 500),
(202310, 2, 450),
(202312, 2, 200),
(202314, 2, 100),
(202316, 2, 400),
(202317, 2, 500),
(202320, 2, 300),
(202321, 2, 400),
(202325, 2, 300),
(202326, 2, 300),
(202328, 2, 500),
(202331, 2, 500),
(202334, 2, 1000),
(202336, 2, 200),
(202337, 2, 600),
(202338, 2, 200),
(202343, 2, 400),
(202344, 2, 200),
(202346, 2, 100),
(202348, 2, 1000),
(202350, 2, 300),
(202353, 2, 700),
(202356, 2, 400),
(202358, 2, 300),
(202359, 2, 400),
(202361, 2, 300);

-- --------------------------------------------------------

--
-- Structure de la table `couter`
--

CREATE TABLE `couter` (
  `numPdt` int(11) NOT NULL,
  `annee` int(11) NOT NULL,
  `prixAchat` int(11) DEFAULT NULL,
  `prixVente` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `couter`
--

INSERT INTO `couter` (`numPdt`, `annee`, `prixAchat`, `prixVente`) VALUES
(1, 2023, 270, 280),
(1, 2024, 270, 290),
(1, 2025, 240, 300),
(2, 2023, 3900, 9500),
(2, 2024, 3800, 10000),
(2, 2025, 3500, 9000);

-- --------------------------------------------------------

--
-- Structure de la table `entree`
--

CREATE TABLE `entree` (
  `numEnt` int(11) NOT NULL,
  `dateEnt` datetime NOT NULL,
  `qteEnt` int(11) NOT NULL,
  `numSau` int(11) NOT NULL,
  `numPdt` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `entree`
--

INSERT INTO `entree` (`numEnt`, `dateEnt`, `qteEnt`, `numSau`, `numPdt`) VALUES
(20231, '2024-01-04 00:00:00', 2000, 1, 1),
(20232, '2024-01-04 00:00:00', 3000, 1, 2),
(20233, '2024-01-09 00:00:00', 2000, 4, 1),
(20234, '2024-01-09 00:00:00', 2000, 4, 2),
(20235, '2024-02-02 00:00:00', 4000, 3, 1),
(20236, '2024-02-05 00:00:00', 3000, 2, 2),
(20237, '2024-03-01 00:00:00', 1000, 4, 1),
(20238, '2024-03-01 00:00:00', 4000, 4, 2),
(20239, '2024-05-07 00:00:00', 3000, 1, 1),
(20241, '2024-06-16 00:00:00', 1000, 1, 1),
(20242, '2024-06-18 00:00:00', 500, 1, 2),
(20243, '2024-07-10 00:00:00', 1500, 2, 2),
(202310, '2024-06-08 00:00:00', 3000, 1, 1),
(202311, '2024-06-08 00:00:00', 3000, 1, 2),
(202312, '2024-06-29 00:00:00', 2000, 3, 1),
(202313, '2024-07-01 00:00:00', 1000, 2, 2),
(202314, '2024-08-07 00:00:00', 3000, 4, 1),
(202315, '2024-08-07 00:00:00', 2000, 4, 2);

-- --------------------------------------------------------

--
-- Structure de la table `produit`
--

CREATE TABLE `produit` (
  `numPdt` int(11) NOT NULL,
  `libPdt` varchar(50) NOT NULL,
  `stockPdt` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `produit`
--

INSERT INTO `produit` (`numPdt`, `libPdt`, `stockPdt`) VALUES
(1, 'Gros sel', 2000),
(2, 'Fleur de sel', 1000);

-- --------------------------------------------------------

--
-- Structure de la table `saunier`
--

CREATE TABLE `saunier` (
  `numSau` int(11) NOT NULL,
  `nomSau` varchar(50) NOT NULL,
  `prenomSau` varchar(50) NOT NULL,
  `villeSau` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `saunier`
--

INSERT INTO `saunier` (`numSau`, `nomSau`, `prenomSau`, `villeSau`) VALUES
(1, 'YVAN', 'Pierre', 'Ars-En-Ré'),
(2, 'PETIT', 'Marc', 'Loix'),
(3, 'CARBRAC', 'Léonie', 'Rivedoux'),
(4, 'TARDIVEL', 'Thierry', 'La Couarde');

-- --------------------------------------------------------

--
-- Structure de la table `sortie`
--

CREATE TABLE `sortie` (
  `numSort` int(11) NOT NULL,
  `dateSort` datetime NOT NULL,
  `numCli` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `sortie`
--

INSERT INTO `sortie` (`numSort`, `dateSort`, `numCli`) VALUES
(20231, '2024-01-05 00:00:00', '10'),
(20232, '2024-01-06 00:00:00', '2'),
(20233, '2024-01-06 00:00:00', '5'),
(20234, '2024-01-06 00:00:00', '11'),
(20235, '2024-01-09 00:00:00', '2'),
(20236, '2024-01-09 00:00:00', '3'),
(20237, '2024-01-12 00:00:00', '11'),
(20238, '2024-01-12 00:00:00', '6'),
(20239, '2024-01-23 00:00:00', '1'),
(20241, '2024-07-16 00:00:00', '1'),
(20242, '2024-07-18 00:00:00', '1'),
(20243, '2024-08-10 00:00:00', '2'),
(202310, '2024-02-14 00:00:00', '10'),
(202311, '2024-02-14 00:00:00', '3'),
(202312, '2024-02-16 00:00:00', '10'),
(202313, '2024-02-28 00:00:00', '9'),
(202314, '2024-03-08 00:00:00', '1'),
(202315, '2024-03-09 00:00:00', '2'),
(202316, '2024-03-10 00:00:00', '10'),
(202317, '2024-03-19 00:00:00', '7'),
(202318, '2024-03-22 00:00:00', '1'),
(202319, '2024-03-23 00:00:00', '10'),
(202320, '2024-03-23 00:00:00', '10'),
(202321, '2024-04-04 00:00:00', '11'),
(202322, '2024-04-06 00:00:00', '11'),
(202323, '2024-04-17 00:00:00', '10'),
(202324, '2024-04-20 00:00:00', '1'),
(202325, '2024-04-29 00:00:00', '11'),
(202326, '2024-05-02 00:00:00', '3'),
(202327, '2024-05-04 00:00:00', '7'),
(202328, '2024-05-22 00:00:00', '11'),
(202329, '2024-06-03 00:00:00', '10'),
(202330, '2024-06-03 00:00:00', '1'),
(202331, '2024-06-04 00:00:00', '11'),
(202332, '2024-06-05 00:00:00', '6'),
(202333, '2024-06-06 00:00:00', '7'),
(202334, '2024-06-07 00:00:00', '8'),
(202335, '2024-06-09 00:00:00', '2'),
(202336, '2024-06-30 00:00:00', '5'),
(202337, '2024-07-01 00:00:00', '10'),
(202338, '2024-07-01 00:00:00', '9'),
(202339, '2024-07-02 00:00:00', '11'),
(202340, '2024-07-13 00:00:00', '5'),
(202341, '2024-07-24 00:00:00', '7'),
(202342, '2024-08-05 00:00:00', '10'),
(202343, '2024-08-06 00:00:00', '10'),
(202344, '2024-08-06 00:00:00', '11'),
(202345, '2024-09-02 00:00:00', '5'),
(202346, '2024-09-08 00:00:00', '1'),
(202347, '2024-09-19 00:00:00', '7'),
(202348, '2024-10-10 00:00:00', '11'),
(202349, '2024-10-11 00:00:00', '4'),
(202350, '2024-11-02 00:00:00', '9'),
(202351, '2024-11-13 00:00:00', '11'),
(202352, '2024-11-14 00:00:00', '10'),
(202353, '2024-11-15 00:00:00', '10'),
(202354, '2024-11-15 00:00:00', '4'),
(202355, '2024-11-15 00:00:00', '6'),
(202356, '2024-12-08 00:00:00', '11'),
(202357, '2024-12-11 00:00:00', '4'),
(202358, '2024-12-20 00:00:00', '10'),
(202359, '2024-12-21 00:00:00', '11'),
(202360, '2024-12-22 00:00:00', '6'),
(202361, '2024-12-23 00:00:00', '2');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `client`
--
ALTER TABLE `client`
  ADD PRIMARY KEY (`numCli`),
  ADD UNIQUE KEY `unique_nom_ville` (`nomCli`,`villeCli`);

--
-- Index pour la table `concerner`
--
ALTER TABLE `concerner`
  ADD PRIMARY KEY (`numPdt`,`numSort`),
  ADD KEY `numSort` (`numSort`);

--
-- Index pour la table `couter`
--
ALTER TABLE `couter`
  ADD PRIMARY KEY (`numPdt`,`annee`);

--
-- Index pour la table `entree`
--
ALTER TABLE `entree`
  ADD PRIMARY KEY (`numEnt`),
  ADD KEY `numSau` (`numSau`),
  ADD KEY `numPdt` (`numPdt`);

--
-- Index pour la table `produit`
--
ALTER TABLE `produit`
  ADD PRIMARY KEY (`numPdt`);

--
-- Index pour la table `saunier`
--
ALTER TABLE `saunier`
  ADD PRIMARY KEY (`numSau`);

--
-- Index pour la table `sortie`
--
ALTER TABLE `sortie`
  ADD PRIMARY KEY (`numSort`),
  ADD KEY `numCli` (`numCli`);

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `concerner`
--
ALTER TABLE `concerner`
  ADD CONSTRAINT `concerner_ibfk_1` FOREIGN KEY (`numPdt`) REFERENCES `produit` (`numPdt`),
  ADD CONSTRAINT `concerner_ibfk_2` FOREIGN KEY (`numSort`) REFERENCES `sortie` (`numSort`);

--
-- Contraintes pour la table `couter`
--
ALTER TABLE `couter`
  ADD CONSTRAINT `couter_ibfk_1` FOREIGN KEY (`numPdt`) REFERENCES `produit` (`numPdt`);

--
-- Contraintes pour la table `entree`
--
ALTER TABLE `entree`
  ADD CONSTRAINT `entree_ibfk_1` FOREIGN KEY (`numSau`) REFERENCES `saunier` (`numSau`),
  ADD CONSTRAINT `entree_ibfk_2` FOREIGN KEY (`numPdt`) REFERENCES `produit` (`numPdt`);

--
-- Contraintes pour la table `sortie`
--
ALTER TABLE `sortie`
  ADD CONSTRAINT `sortie_ibfk_1` FOREIGN KEY (`numCli`) REFERENCES `client` (`numCli`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
