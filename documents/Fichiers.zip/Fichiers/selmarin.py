import mysql.connector
import csv 
from tkinter import messagebox, ttk, filedialog
from datetime import datetime

def convert_date(date_str):
    try:
        return datetime.strptime(date_str, "%d/%m/%Y").strftime("%Y-%m-%d")
    except ValueError:
        print(" Date invalide ignorée : " + date_str)
        return None  # Pour éviter d'insérer une mauvaise date


# Mise en place des paramètres de la base
params = {"host":"localhost",
          "user":"root",
          "password":"",
          "database":"selmarin-tdb"}

# Test de connexion à la base
try:
    db = mysql.connector.connect(**params)
    cursor = db.cursor()
    print("Connexion réussie")

except mysql.connector.Error as err:
    print("Erreur MySQL :" , {err})


# Code permettant la mise à jour des sauniers
def insert_saunier():
        file_path = filedialog.askopenfilename(filetypes=[("CSV files", "*.csv")])
        if not file_path:
            return
        try:
            with open(file_path, newline='', encoding='latin1') as file:  # Encodage latin1 pour lire le fichier
                reader = csv.reader(file, delimiter=";")
                next(reader)  # Ignorer l'en-tête du CSV
                inserted_count = 0  # Compteur pour suivre les éléments insérés

                for row in reader:
                    if len(row) < 4:
                        print("Ligne ignorée (colonnes manquantes) :", row)
                        continue
                    numSau, nomSau, prenomSau, villeSau = row
                    cursor.execute("SELECT COUNT FROM saunier WHERE numSau = %s", (numSau,))
                    if cursor.fetchone()[0] == 0:
                        requete = "INSERT INTO saunier (numSau, nomSau, prenomSau, villeSau) VALUES (%s, %s, %s, %s)"
                        cursor.execute(requete, (numSau, nomSau, prenomSau, villeSau))
                        db.commit()
                        inserted_count += 1  # Incrémenter le compteur

                if inserted_count == 0:
                    messagebox.showinfo("Info", "Aucun élément ajouté. La table SAUNIER est à jour.")
                else:
                    messagebox.showinfo("Info", f"{inserted_count} élément(s) ajouté(s) dans la table SAUNIER.")

        except Exception as e:
            messagebox.showerror("Erreur", f"Erreur lors de l'insertion : {e}")

#  Code permettant la mise à jour des clients
def insert_client():
        file_path = filedialog.askopenfilename(filetypes=[("CSV files", "*.csv")])
        if not file_path:
            return
        try:
            with open(file_path, newline='', encoding='utf-8') as file:
                reader = csv.reader(file, delimiter=";")
                next(reader)  # Ignorer l'en-tête du CSV
                inserted_count = 0  # Compteur pour suivre les éléments insérés

                for row in reader:
                    if len(row) < 4:
                        print("Ligne ignorée (colonnes manquantes) :", row)
                        continue
                    numCli, nomCli, precisionCli, villeCli = row
                    cursor.execute("SELECT COUNT FROM client WHERE numCli = %s", (numCli,))
                    if cursor.fetchone()[0] == 0:
                        requete = "INSERT INTO client (numCli, nomCli, precisionCli, villeCli) VALUES (%s, %s, %s, %s)"
                        cursor.execute(requete, (numCli, nomCli, precisionCli, villeCli))
                        db.commit()
                        inserted_count += 1  # Incrémenter le compteur

                if inserted_count == 0:
                    messagebox.showinfo("Info", "Aucun élément ajouté. La table CLIENT est à jour.")
                else:
                    messagebox.showinfo("Info", f"{inserted_count} élément(s) ajouté(s) dans la table CLIENT.")

        except Exception as e:
            messagebox.showerror("Erreur", f"Erreur lors de l'insertion : {e}")
     
#   Code permettant la mise à jour des entrées
def insert_entree():
        file_path = filedialog.askopenfilename(filetypes=[("CSV files", "*.csv")])
        if not file_path:
            return
        try:
            with open(file_path, newline='', encoding='utf-8') as file:
                reader = csv.reader(file, delimiter=";")
                next(reader)  # Ignorer l'en-tête du CSV
                inserted_count = 0  # Compteur pour suivre les éléments insérés

                for row in reader:
                    if len(row) < 5:
                        print("Ligne ignorée (colonnes manquantes) :", row)
                        continue
                    numEnt, dateEnt, qteEnt, numPdt, numSau = row
                    dateEnt = convert_date(dateEnt)

                    cursor.execute("SELECT COUNT FROM entree WHERE numEnt = %s", (numEnt,))
                    if cursor.fetchone()[0] == 0:
                        requete = "INSERT INTO entree (numEnt, dateEnt, qteEnt, numPdt, numSau) VALUES (%s, %s, %s, %s, %s)"
                        cursor.execute(requete, (numEnt, dateEnt, qteEnt, numPdt, numSau))
                        db.commit()
                        inserted_count += 1  # Incrémenter le compteur

                if inserted_count == 0:
                    messagebox.showinfo("Info", "Aucun élément ajouté. La table ENTREE est à jour.")
                else:
                    messagebox.showinfo("Info", f"{inserted_count} élément(s) ajouté(s) dans la table ENTREE.")

        except Exception as e:
            messagebox.showerror("Erreur", f"Erreur lors de l'insertion : {e}")

# Pour insérer les données du fichier sortie.csv dans la table sortie il faut faire correspondre chaque ligne du fichier avec la table concerner
def insert_sortie():
    file_path = filedialog.askopenfilename(filetypes=[("CSV files", "*.csv")])
    if not file_path:
        return
    try:
        with open(file_path, newline='', encoding='utf-8') as file:
            reader = csv.reader(file, delimiter=";")
            next(reader)  # Ignorer l'en-tête du CSV (si nécessaire)

            inserted_count_sortie = 0  # Compteur pour les ajouts dans la table sortie
            inserted_count_concerner = 0  # Compteur pour les ajouts dans la table concerner

            for row in reader:
                if len(row) < 5:
                    continue  # Ignorer les lignes avec des colonnes manquantes

                numSort = row[0]
                dateSort = convert_date(row[1])
                numCli = row[2]
                numPdt = row[3]
                qteSort = row[4]

                # Vérifier si l'entrée existe déjà dans la table sortie
                cursor.execute("SELECT COUNT FROM sortie WHERE numSort = %s", (numSort,))
                if cursor.fetchone()[0] == 0:
                    # Insérer dans la table sortie
                    sql = """INSERT INTO sortie (numSort, dateSort, numCli) VALUES (%s, %s, %s)"""
                    cursor.execute(sql, (numSort, dateSort, numCli))
                    db.commit()
                    inserted_count_sortie += 1  # Incrémenter le compteur pour sortie

                # Vérifier que le couple numSort et numPdt n'existe pas déjà dans la table concerner
                cursor.execute("SELECT COUNT FROM concerner WHERE numSort = %s AND numPdt = %s", (numSort, numPdt))
                if cursor.fetchone()[0] == 0:
                    # Insérer dans la table concerner
                    requete = """INSERT INTO concerner (numSort, numPdt, qteSort) VALUES (%s, %s, %s)"""
                    cursor.execute(requete, (numSort, numPdt, qteSort))
                    db.commit()
                    inserted_count_concerner += 1  # Incrémenter le compteur pour concerner

            # Afficher un message en fonction des résultats
            if inserted_count_sortie == 0 and inserted_count_concerner == 0:
                messagebox.showinfo("Info", "Aucun élément ajouté. Les tables SORTIE et CONCERNER sont à jour.")
            else:
                messagebox.showinfo(
                    "Info",
                    f"{inserted_count_sortie} élément(s) ajouté(s) dans la table SORTIE.\n"
                    f"{inserted_count_concerner} élément(s) ajouté(s) dans la table CONCERNER."
                )

    except Exception as e:
        messagebox.showerror("Erreur", f"Erreur lors de l'insertion : {e}")
     

insert_saunier()
insert_client()
insert_entree()
insert_sortie()